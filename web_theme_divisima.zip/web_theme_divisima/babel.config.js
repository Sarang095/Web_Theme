module.exports = {
    presets: [
        require.resolve('next/babel')
    ]
};